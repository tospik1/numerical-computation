clc
clear all
close all

n = 1:100;
xn = zeros(1,100);

%%
% Question 3(b)

for i=1:100
    xn(1,i) = (2^i)*(sqrt(1+2^(-i)) - 1);
end

figure(1);
plot(n,xn);
title('Plotting  first 100 terms of sequence');
xlabel('n');
ylabel('x_n');

%%
% Question 3(c)
% Improvement of formula due to numerical difficulty encountered in 3(b)

xn_improved = zeros(1,100);

for i=1:100
    xn_improved(1,i) = 1/(1+sqrt(1+2^(-i)));
end

figure(2);
plot(n,xn_improved);
title('Plotting  first 100 terms of sequence with improved formula');
xlabel('n');
ylabel('xi_n');

