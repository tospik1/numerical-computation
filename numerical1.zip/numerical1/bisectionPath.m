function [ vec ] = bisectionPath(fname, a, b, nmax)

    % Assuming fname(a)<0 and fname(b)>0

    vec = zeros(nmax+1,2);
    vec(1,:)=[a,b];
    
    for i=1:nmax
        c = (a+b)/2;
        
        if(fname(c)<0)
            a=c;
        else
            b=c;
        end
        
        vec(i+1,:)=[a,b];
    end
end

