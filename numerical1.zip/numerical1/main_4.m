clc
close all
clear all

fname = @(x) x^3-2;

disp(['Root of polynomial x^3-2 will be ',num2str(secant(fname, 1, 1.e-12, 1.e-12, 20))]);


