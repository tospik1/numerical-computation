clc
close all
clear all

fname=@(x) x^2-5;
fdname = @(x) 2*x;

bisectionPath(fname,0,4,20)
newtonPath(fname,fdname,4,20)
secantPath(fname,4,20)

