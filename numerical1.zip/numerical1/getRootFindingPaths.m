function [] = getRootFindingPaths(fname, fdname, nmax, numPaths, trueRoot)

    pathTrueRoot = trueRoot*ones(nmax+1,1);
    
    pathB = bisectionPath(fname,0,2,nmax);
    log10ErrB = log10( abs(pathB(:,1) - pathTrueRoot) );
    
    pathN = newtonPath(fname,fdname,randn(),nmax);
    log10ErrN = log10( abs(pathN - pathTrueRoot) );
    
    pathS = secantPath(fname,randn(),nmax);
    log10ErrS = log10( abs(pathS(:,1) - pathTrueRoot) );
    
    figure(1);
    plot(1:(nmax+1),log10ErrB);
    hold on;
    plot(1:(nmax+1),log10ErrN);
    plot(1:(nmax+1),log10ErrS);
    title('Plotting erros along the path for different root finding methods');
    legend('Bisection method','Newton method','Secant method');
    xlabel('Iteration number');
    ylabel('Error values');
    
end

