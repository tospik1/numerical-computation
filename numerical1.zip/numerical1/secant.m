function [root] = secant(fname, x, xtol, ftol, nmax)

    x0 = 0;
    x1 = x;
    
    for i=1:nmax
        x2 = x1 - ((x1-x0)/(fname(x1)-fname(x0)))*fname(x1);
        x0 = x1;
        x1 = x2;
        
        if (abs(x0-x1)<=xtol || abs(fname(x0)-fname(x1))<=ftol)
            break;
        end
    end
    
    root=x1;

end

