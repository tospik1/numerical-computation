function [ vec ] = secantPath(fname, x, nmax)
    
    vec = zeros(nmax+1,2);
    vec(1,:) = [0,x];
    
    x0 = 0;
    x1 = x;
    
    for i=1:nmax
        x2 = x1 - ((x1-x0)/(fname(x1)-fname(x0)))*fname(x1);
        x0 = x1;
        x1 = x2;
        
        if(fname(x1)==fname(x0))
            vec(i+1:nmax+1,:) = [x0*ones(nmax-i+1,1),x1*ones(nmax-i+1,1)];
            break;
        end
        
        vec(i+1,:) = [x0,x1];
    end
    
end

