clc
clear all
close all

fname = @(x) x^3-2;
fdname = @(x) 3*x^2;

getRootFindingPaths(fname,fdname,20,100,2^(1/3))

