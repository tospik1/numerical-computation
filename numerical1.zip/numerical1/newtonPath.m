function [ vec ] = newtonPath(fname, fdname, x, nmax)

    vec = zeros(nmax+1,1);
    vec(1,1) = x;
    
    for i=1:nmax
        x1 = x - (fname(x)/fdname(x));
        x=x1;
        vec(i+1,1) = x;
        
    end

end

